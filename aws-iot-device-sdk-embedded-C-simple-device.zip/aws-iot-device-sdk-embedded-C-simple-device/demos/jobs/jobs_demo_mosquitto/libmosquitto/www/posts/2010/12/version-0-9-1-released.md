<!--
.. title: Version 0.9.1 released
.. slug: version-0-9-1-released
.. date: 2010-12-03 11:04:26
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release.

 * Add missing code for parsing the `bind_address` configuration option.
 * Fix missing include when compiling with tcp-wrappers support.
 * Add linker version script for C library to control exported functions.

Source code is on the [download page], binary packages will follow on later.

[download page]: /download
