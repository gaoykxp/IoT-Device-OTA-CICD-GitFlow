<!--
.. title: libmosquitto Go bindings
.. slug: libmosquitto-go-bindings
.. date: 2012-12-24 00:18:18
.. tags: Solutions
.. category:
.. link:
.. description:
.. type: text
-->

I just discovered that Shane Hanna has written a Go language binding for
libmosquitto available at <https://bitbucket.org/shanehanna/mosquitto/>.
Good work Shane! Note that the readme file states:

> Doesn't expose all of libmosquitto, just what I've needed so far.

so you shouldn't necessarily expect everything to work.
