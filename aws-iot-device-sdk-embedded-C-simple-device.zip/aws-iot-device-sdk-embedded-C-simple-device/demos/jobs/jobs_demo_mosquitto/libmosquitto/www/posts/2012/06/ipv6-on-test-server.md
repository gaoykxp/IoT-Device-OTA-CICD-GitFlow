<!--
.. title: IPv6 on Test Server
.. slug: ipv6-on-test-server
.. date: 2012-06-29 09:49:41
.. tags: Testing
.. category:
.. link:
.. description:
.. type: text
-->

The public Mosquitto test server, [test.mosquitto.org] has supported IPv6 since
it was originally put online but the required DNS record was missing. This has
now been fixed so once the record has propagated across the internet you should
be able to test your IPv6 clients.

[test.mosquitto.org]: http://test.msoquitto.org/
