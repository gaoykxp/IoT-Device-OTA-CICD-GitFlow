<!--
.. title: Version 0.14.4 released
.. slug: version-0-14-4-released
.. date: 2012-01-07 16:24:14
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

This is a bugfix release:

 * Fix local bridge notification messages.
 * Fix return values for more internal library calls.
 * Fix incorrect out of memory checks in library and broker.
 * Never time out local bridge connections.
