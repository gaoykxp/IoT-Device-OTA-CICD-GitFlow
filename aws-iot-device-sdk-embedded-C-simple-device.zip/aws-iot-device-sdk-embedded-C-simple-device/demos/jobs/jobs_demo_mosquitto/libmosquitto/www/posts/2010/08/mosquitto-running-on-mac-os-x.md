<!--
.. title: Mosquitto running on Mac OS X
.. slug: mosquitto-running-on-mac-os-x
.. date: 2010-08-08 09:58:26
.. tags: demo,mac,video
.. category:
.. link:
.. description:
.. type: text
-->

Andy Piper has put together a 2 minute screencast demoing mosquitto running on
Mac OS X and showing publishing and subscribing using the mosquitto command
line clients and the IBM java gui client.

View the screen cast here: <http://www.youtube.com/watch?v=SP9Vv3Rksm8>.

Thanks Andy!
