<!--
.. title: MQTT News
.. slug: mqtt-news
.. date: 2011-01-12 09:04:06
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

Here are some MQTT updates from out there on the internet:

A new perl client implementation by Mark Hindess

 * <https://github.com/beanz/net-mqtt-perl>

A [homebrew] recipe for installing mosquitto on Mac by Adam Rudd

 * <https://github.com/mxcl/homebrew/pull/3824>

MQTT implemented for the mbed processor by Yiluin Fan

 * <http://ceit.uq.edu.au/content/mbed-client-mqtt-version-10>

[homebrew]: http://brew.sh/
