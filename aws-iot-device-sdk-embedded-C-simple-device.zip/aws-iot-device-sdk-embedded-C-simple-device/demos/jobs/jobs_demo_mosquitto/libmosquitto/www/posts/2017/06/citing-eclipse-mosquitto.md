<!--
.. title: Citing Eclipse Mosquitto in your academic paper
.. slug: citing-eclipse-mosquitto
.. date: 2017-06-01 14:31:48
.. tags: Misc
.. category:
.. link:
.. description:
.. type: text
-->

A short paper has been published on Mosquitto in [The Journal of Open Source
Software] If you use Mosquitto in your academic work, please now use this paper
as your citation.

> R. A. Light, "Mosquitto: server and client implementation of the MQTT
> protocol," *The Journal of Open Source Software*, vol. 2, no. 13, May 2017,
> DOI: [10.21105/joss.00265]

The paper link is <http://dx.doi.org/10.21105/joss.00265>

A [bibtex] entry is available.

[The Journal of Open Source Software]: http://joss.theoj.org
[10.21105/joss.00265]: http://dx.doi.org/10.21105/joss.00265
[bibtek]: http://www.doi2bib.org/#/doi/10.21105/joss.00265
