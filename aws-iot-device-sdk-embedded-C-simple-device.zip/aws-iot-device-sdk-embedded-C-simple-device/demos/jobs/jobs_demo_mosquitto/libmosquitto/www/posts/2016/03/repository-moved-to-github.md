<!--
.. title: Repository moved to github
.. slug: repository-moved-to-github
.. date: 2016-03-11 09:35:54
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

The mosquitto repository is now hosted on github:
<https://github.com/eclipse/mosquitto> This is now the canonical location for
mosquitto development work.

Bug reports should also be made on github and the existing bug reports will be
migrated over shortly.

The documentation still needs updating with the new location and processes, so
please do be patient with regards that.

Contributions can now be made through a github pull request. If you want to
contribute a bug fix, please base your work off the "fixes" branch, if you are
developing a new feature please use the "develop" branch.

Here's to a new stage in the mosquitto project!
