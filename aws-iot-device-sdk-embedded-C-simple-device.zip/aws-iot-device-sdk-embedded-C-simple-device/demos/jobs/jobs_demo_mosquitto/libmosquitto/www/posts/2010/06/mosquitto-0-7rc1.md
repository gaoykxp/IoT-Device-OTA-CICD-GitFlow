<!--
.. title: Mosquitto 0.7rc1
.. slug: mosquitto-0-7rc1
.. date: 2010-06-04 18:10:57
.. tags: Releases
.. category:
.. link:
.. description:
.. type: text
-->

Mosquitto 0.7 release candidate 1 is available for testing. Please give it a
try and report back any problems you find. The source code is available at 
<http://mosquitto.org/files/source/rc/> and I'll hopefully have various
binaries available soon.
