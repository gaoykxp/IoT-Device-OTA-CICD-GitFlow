<!--
.. title: Help wanted – RPM packaging
.. slug: help-wanted-rpm-packaging
.. date: 2010-04-26 16:59:30
.. tags: Packaging,Support
.. category:
.. link:
.. description:
.. type: text
-->

I'm currently working on the finishing touches of mosquitto 0.6 and will
hopefully be releasing it some time this week in time for oggcamp. Mosquitto is
pretty usable now so I'm keen on making it as easy as possible for people to
get and use. The ultimate goal is of course to get it into the major Linux
distros so it appears in the normal package repositories. Until then, other
solutions are possible. I can provide Windows executables and have a PPA to
support Ubuntu Linux users, but don't have anything for rpm based distros.

Can you help? I'm quite happy using the opensuse build service to build and
host the final packages, but the creation of the rpm build script isn't
something I know how to do at the moment. Given the amount of time I've spent
on the Debian style packaging, I thought I'd ask for help with rpms! :)

If you've got familiarity with rpm and would like to help, please [get in
touch]. If you aren't familiar with creating rpms but want a reason to learn,
that would suit me fine as well.

Thanks in advance!

[get in touch]: /support
