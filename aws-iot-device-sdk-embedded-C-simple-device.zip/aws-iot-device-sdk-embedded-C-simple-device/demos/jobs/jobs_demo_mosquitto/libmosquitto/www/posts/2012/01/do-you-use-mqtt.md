<!--
.. title: Do you use MQTT?
.. slug: do-you-use-mqtt
.. date: 2012-01-05 22:21:49
.. tags: Applications
.. category:
.. link:
.. description:
.. type: text
-->

I saw this in the nanode irc channel:

> I've never seen any real world projects with MQTT... it looks good though.

So I'm looking for real world projects that use MQTT. If you've got a project
it'd be great if you could mention it in the comments. A short sentence on what
it does and how many clients you run on it - really anything you can say. If
it's a secret please still comment if you can, just be very very vague. If
you've got a blog post describing it, link that instead. I'm interested in
everything from a single temperature sensor reporting to a computer up to
millions of mobile users.

Thanks!
