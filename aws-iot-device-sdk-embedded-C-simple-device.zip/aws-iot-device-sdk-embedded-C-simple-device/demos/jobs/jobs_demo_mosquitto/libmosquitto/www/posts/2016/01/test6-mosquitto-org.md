<!--
.. title: test6.mosquitto.org
.. slug: test6-mosquitto-org
.. date: 2016-01-14 20:35:33
.. tags: Misc
.. category:
.. link:
.. description:
.. type: text
-->

Thanks to a short discussion on irc, test6.mosquitto.org now exists. This is a
DNS entry that points to the same address as test.mosquitto.org, but only with
an AAAA record. This means that test6.mosquitto.org can be used to test clients
using IPv6 and to be sure that IPv6 is actually being used.
