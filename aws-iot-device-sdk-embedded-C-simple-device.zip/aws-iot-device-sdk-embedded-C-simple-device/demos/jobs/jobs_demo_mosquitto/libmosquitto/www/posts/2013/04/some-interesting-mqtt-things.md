<!--
.. title: Some interesting MQTT things
.. slug: some-interesting-mqtt-things
.. date: 2013-04-21 21:56:36
.. tags:
.. category:
.. link:
.. description:
.. type: text
-->

It's been a while since there has been an update here, so in lieu of one here
are some interesting links I've come across recently. Add a comment to the post
if you've done something cool not mentioned here! Work progresses on mosquitto
1.2.

Initial release of an MQTT-S gateway, written in ruby:

 * <https://github.com/njh/ruby-em-mqtts>

And some MQTT-S tools:

 * <https://github.com/njh/mqtts-tools>

A Pinoccio/MQTT/sensor powered Theramin:

 * <http://projectable.me/post/48408382189/scout6050-a-combination-of-pinoccio-mpu6050>

Voice controlled MQTT LED:

 * <https://github.com/emmano/voicerecog4pi>

An MQTT notification plugin for Jenkins/Hudson:

 * <https://github.com/gdubya/mqtt-notification-plugin>
