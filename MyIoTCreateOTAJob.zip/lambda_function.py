import json
import pathlib
from pathlib import Path
import random
import boto3
import base64
import urllib.parse
import time
from boto3.dynamodb.conditions import Key

code_pipeline = boto3.client('codepipeline')
s3 = boto3.client('s3')

class AWS_IoT_OTA:

    # Get the latest version
    def GetLatestS3FileVersion(self):
        try: 
            versions=self.s3.meta.client.list_object_versions(Bucket=self.s3bucket, Prefix=self.APP_NAME)['Versions']
            latestversion = [x for x in versions if x['IsLatest']==True]
            self.latestVersionId=latestversion[0]['VersionId']
            #print("Using version %s" % self.latestVersionId)
        except Exception as e:
            print("Error getting versions: %s" % e)
            sys.exit

    def CreateOTAJob(self):
        # Create OTA job
        try:
            iot = boto3.client('iot')
            randomSeed=random.randint(1, 65535)
            #Initialize the template to use
            filePath = self.APP_NAME.split('/')[1]
            print('filePath is : ' + filePath )
            files=[{
                'fileName': filePath,
                    'fileVersion': '1',
                    'fileLocation': {
                        's3Location': {
                            'bucket': 'iot-things-ota',
                            'key': self.APP_NAME,
                            'version': self.latestVersionId
                        }
                    },
                    'codeSigning':{
                        'startSigningJobParameter':{
                            'signingProfileName': 'kenny_fw_ota_test',
                            'destination': {
                                's3Destination': {
                                    'bucket': 'iot-things-ota'
                                }
                            }
                        }
                    }    
                }] 

            target="arn:aws:iot:us-west-2:776353586321:thing/IoT-device-c-test"
            updateId="simpledevice-"+str(randomSeed) + "-"+ "Dev"

            print ("Files for update: %s" % files)
            
            ota_update=iot.create_ota_update(
                otaUpdateId=updateId,
                targetSelection='SNAPSHOT',
                files=files,
                protocols=['MQTT'],
                targets=[target],
                roleArn="arn:aws:iam::776353586321:role/IoTThingsOTA-Role"
            )

            print("OTA Update Status: %s" % ota_update)

        except Exception as e:
            print("Error creating OTA Job: %s" % e)
            sys.exit


    def __init__(self, s3bucket, imageName):
        self.s3 = boto3.resource('s3')
        self.s3bucket = s3bucket
        self.APP_NAME = imageName
        print(self.APP_NAME)
    

    def DoUpdate(self):
        self.GetLatestS3FileVersion()
        self.CreateOTAJob()


    
def lambda_handler(event, context):
    # TODO implement
    print("lambda_handler......")
    print(event)

    if 'Records' in event:
        # Get the app image object from the event and create OTA
        bucket = event['Records'][0]['s3']['bucket']['name']
        object = event['Records'][0]['s3']['object']['key']
        print(bucket + '-' + object)
        ota = AWS_IoT_OTA(bucket, object)
        ota.DoUpdate()
        #time.sleep(3)
        print('ota job creating')
    elif 'operation' in event:
        # Read the Job ID to DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('IoT-OTA-Pipeline')
        response = table.query(KeyConditionExpression=Key('pipeline_ID').eq('latest'))
        print(response)
        pipeline_job_id = response['Items'][0]['JobID']
        print("verify ota job status ,pipeline_job_id: %s" % pipeline_job_id)
        if event['operation'] == 'completed':
            code_pipeline.put_job_success_result(jobId=pipeline_job_id)
        else:
            code_pipeline.put_job_failure_result(jobId=pipeline_job_id, failureDetails={'message': 'OTA test', 'type': 'JobFailed'})

    else:
        # Extract the Job ID
        pipeline_job_id = event['CodePipeline.job']['id']

        print("pipeline_job_id: %s" % pipeline_job_id)
        # Save the Job ID to DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('IoT-OTA-Pipeline')
        table.put_item(Item={'pipeline_ID': 'latest', 'JobID': pipeline_job_id})

    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
